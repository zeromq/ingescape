char *strndup(const char *str, int chars);
